# AI Political Supremacy (AIPS)

This project aims to use AI for political analysis.